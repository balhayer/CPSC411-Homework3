package com.csuf.cpsc411.homework_3;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.csuf.cpsc411.homework_3.adapter.SummaryLVAdapter;

import java.io.File;

public class MainActivity extends Activity {

    protected ListView mSummaryView;
    protected Menu addMenu;
    protected Button btn;
    protected final String TAG = "Summary Screen";
    protected SummaryLVAdapter ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.summary_listview);

        mSummaryView = findViewById(R.id.summary_list_view_id);

        ad = new SummaryLVAdapter(this);
        mSummaryView.setAdapter(ad);

        File dbFile = this.getDatabasePath("student.db");
        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(dbFile,null);

        db.execSQL("CREATE TABLE IF NOT EXISTS Student (FirstName Text, LastName Text, CWID Integer)");
        db.execSQL("CREATE TABLE IF NOT EXISTS Courses (CourseName Text, CourseGrade Text, CWID Integer)");

        db.execSQL("DELETE FROM Student WHERE CWID=?", new String[]{"888888888"});
        db.execSQL("DELETE FROM Courses WHERE CWID=?", new String[]{"888888888"});
        db.execSQL("INSERT INTO Student VALUES (?,?,?)", new String[]{"Michael", "Scott", "888888888"});
        db.execSQL("INSERT INTO Courses VALUES ('ACCT 101', 'F', 888888888)");
        db.execSQL("INSERT INTO Courses VALUES ('BUAD 101', 'C', 888888888)");

        db.close();

        btn = (Button)findViewById(R.id.add_student_button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddStudentActivity.class));
            }
        });

    }

    @Override
    protected void onStart() {
        ad.notifyDataSetChanged();
        ad.refreshStudents();
        super.onStart();
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause() called ");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d(TAG, "onStop() called");
        super.onStop();
    }

    @Override
    protected void onResume() {
        Log.d(TAG, "onResume() called");
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy() called");
        super.onDestroy();
    }
}